import java.util.Random;
public class Sumb{
  public static int rand(int min, int max)
  {
    if (min < max || (max - min + 1 <= Integer.MAX_VALUE)) {
      return new Random().nextInt(max - min + 1) + min;
    }
    else{
      throw new IllegalArgumentException("invalid int");
    }
  }

  int binarySearch(int arr[], int x)
  {
      int l = 0, r = arr.length - 1;
      while (l <= r) {
          int m = l + (r - l) / 2;

          if (arr[m] == x)
              return m;

          if (arr[m] < x)
              l = m + 1;

          else
              r = m - 1;
      }

      return -1;
  }

public static void main(String args[])
{

  		Sumb ob = new Sumb();

        int[] size = {100, 1000, 100000, 1000000};
        for(int k = 0; k < size.length; k++){
        int[] arr = new int[size[k]];

      for (int j = 0; j < arr.length; j++) {
        arr[j] = rand(-100, 100);
      }
      int n = arr.length;
  		int sum = rand(-200, 200);
      int temp = 0;
      long startTime = System.currentTimeMillis();
      loop:
      for(int i = 0; i < n; i++){
      temp = sum - arr[i];
  		int result = ob.binarySearch(arr, temp);
  		if (result != -1){
        long stopTime = System.currentTimeMillis();
        System.out.println("array size: "+ size[k] +" i = " + arr[i] + " j = " + temp + " sum = " + sum +"  time: "+ (stopTime - startTime) + "ms" +"\n");
        break loop;
      }
      }
}
}
}
