import java.util.Random;
public class Sum{
  public static int rand(int min, int max)
  {
    if (min < max || (max - min + 1 <= Integer.MAX_VALUE)) {
      return new Random().nextInt(max - min + 1) + min;
    }
    else{
      throw new IllegalArgumentException("invalid int");
    }
  }

public static void main(String args[])
{

  int[] size = {100, 1000, 100000, 1000000};
  for(int k = 0; k < size.length; k++){
  int[] array = new int[size[k]];

  for (int j = 0; j < array.length; j++) {
    array[j] = rand(-100, 100);
  }
int sum = rand(-200, 200);
int temp = 0;
long startTime = System.currentTimeMillis();
loop:
for(int i = 0; i < array.length; i++){
  for(int j = 0; j <array.length; j++){
  temp = array[i]+array[j];
    if(temp == sum){
      long stopTime = System.currentTimeMillis();
      System.out.println("array size: "+ size[k] +" i = " + array[i] + " j = " + array[j] + " sum = " + temp +"  time: "+ (stopTime - startTime) + "ms" + "\n");
      break loop;
    }
  }
}
}
}
}
